library(testthat)
library(bwgtools)

test_check("bwgtools")
